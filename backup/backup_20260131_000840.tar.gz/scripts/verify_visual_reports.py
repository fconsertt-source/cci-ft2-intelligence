import os
import sys
import pandas as pd
from datetime import datetime
from pathlib import Path

# Add src to path
sys.path.append(str(Path(__file__).parent.parent))

from src.reporting.unified_pdf_generator import UnifiedPDFGenerator, ReportType

def create_mock_data(path: str):
    """Creates a TSV with diverse v1.1.0 scenarios for visual testing."""
    data = {
        'center_id': ['C001', 'C002', 'C003', 'C004', 'C005'],
        'center_name': ['Health Center A (Safe)', 'Warehouse Stage 3', 'Mobile Unit Stage 4', 'Ultra Cold Hub', 'Critical Alert'],
        'decision': ['ACCEPTED', 'ACCEPTED', 'REJECTED', 'ACCEPTED', 'REJECTED'],
        'alert_level': ['GREEN', 'YELLOW', 'RED', 'YELLOW', 'RED'],
        'vvm_stage': ['NONE', 'STAGE_B', 'STAGE_D', 'NONE', 'STAGE_D'],
        'stability_budget_consumed_pct': [5.2, 100.0, 150.0, 65.0, 200.0],
        'thaw_remaining_hours': ['N/A', 'N/A', 'N/A', '72.5', 'N/A'],
        'category_display': ['Fridge Vaccine', 'Heat Sensitive', 'Highly Sensitive', 'mRNA Vaccine', 'Heat Sensitive'],
        'avg_temperature': [4.5, 7.2, 12.5, 3.8, 15.0],
        'min_temperature': [2.1, 4.0, 5.5, 2.0, 10.0],
        'max_temperature': [6.8, 9.5, 15.0, 5.2, 20.0],
        'num_ft2_entries': [100, 150, 200, 80, 50],
        'decision_reasons': ['Safe', 'Warning: HER=82%', 'Critical: HER=150%', 'Warning: Stage 2', 'Absolute Discard']
    }
    df = pd.DataFrame(data)
    df.to_csv(path, sep='\t', index=False)
    print(f"Mock data created at: {path}")

def main():
    output_dir = "data/output/visual_tests"
    os.makedirs(output_dir, exist_ok=True)
    
    data_path = os.path.join(output_dir, "mock_visual_data.tsv")
    create_mock_data(data_path)
    
    gen = UnifiedPDFGenerator(output_dir=output_dir)
    
    print("Generating Official Visual Report...")
    official_path = gen.generate(ReportType.OFFICIAL, data_path, "visual_test_official.pdf")
    print(f"Done: {official_path}")
    
    print("Generating Technical Visual Report...")
    tech_path = gen.generate(ReportType.TECHNICAL, data_path, "visual_test_tech.pdf")
    print(f"Done: {tech_path}")

    print("Generating Arabic Visual Report...")
    arabic_path = gen.generate(ReportType.ARABIC, data_path, "visual_test_arabic.pdf")
    print(f"Done: {arabic_path}")

if __name__ == "__main__":
    main()
